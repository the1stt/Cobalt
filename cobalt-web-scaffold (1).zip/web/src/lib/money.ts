// Money is integer cents everywhere. Formatting uses integer maths only,
// never floating-point division.
export function formatUSD(cents: number): string {
  if (!Number.isSafeInteger(cents)) {
    throw new Error("formatUSD expects an integer number of cents");
  }
  const negative = cents < 0;
  const abs = Math.abs(cents);
  const dollars = Math.trunc(abs / 100);
  const remainder = abs % 100;
  return `${negative ? "-" : ""}$${dollars.toLocaleString("en-US")}.${String(remainder).padStart(2, "0")}`;
}
