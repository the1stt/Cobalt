import { redirect } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { logOut } from "@/app/(auth)/actions";

// Placeholder. The real form (handle, name, date of birth, address) is the next step.
export default async function OnboardingPage() {
  const user = await requireUser();
  const supabase = await createClient();
  const { data: profile } = await supabase
    .from("profiles")
    .select("id")
    .eq("id", user.id)
    .maybeSingle();
  if (profile) redirect("/home");

  return (
    <main className="flex min-h-screen items-center justify-center bg-neutral-50 px-4 text-neutral-900 dark:bg-neutral-950 dark:text-neutral-100">
      <div className="w-full max-w-sm space-y-4">
        <h1 className="text-lg font-medium">Almost there</h1>
        <p className="text-sm text-neutral-500">
          You&apos;re signed in as {user.email}. The onboarding form arrives in the next step.
        </p>
        <form action={logOut}>
          <button className="text-sm font-medium text-blue-700 dark:text-blue-400">Log out</button>
        </form>
      </div>
    </main>
  );
}
