import { AuthForm } from "../auth-form";
import { signUp } from "../actions";

export default function SignupPage() {
  return (
    <>
      <h1 className="mb-4 text-lg font-medium">Create your account</h1>
      <AuthForm mode="signup" action={signUp} />
    </>
  );
}
