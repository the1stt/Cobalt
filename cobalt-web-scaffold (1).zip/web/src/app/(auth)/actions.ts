"use server";

import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import type { FormState } from "@/lib/form-state";

const credentials = z.object({
  email: z.string().trim().toLowerCase().email("Enter a valid email address."),
  password: z
    .string()
    .min(8, "Use at least 8 characters.")
    .max(72, "Use 72 characters or fewer."),
});

async function getOrigin() {
  const h = await headers();
  const host = h.get("x-forwarded-host") ?? h.get("host") ?? "localhost:3000";
  const proto =
    h.get("x-forwarded-proto") ?? (host.startsWith("localhost") ? "http" : "https");
  return `${proto}://${host}`;
}

function rawEmail(formData: FormData) {
  const v = formData.get("email");
  return typeof v === "string" ? v : "";
}

export async function signUp(_prev: FormState, formData: FormData): Promise<FormState> {
  const parsed = credentials.safeParse({
    email: formData.get("email"),
    password: formData.get("password"),
  });
  if (!parsed.success) {
    return { error: parsed.error.issues[0].message, email: rawEmail(formData) };
  }
  const { email, password } = parsed.data;

  const supabase = await createClient();
  const origin = await getOrigin();
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: { emailRedirectTo: `${origin}/auth/confirm?next=/onboarding` },
  });

  if (error) {
    if (error.code === "weak_password") {
      return { error: "Choose a stronger password.", email };
    }
    if (error.code === "over_request_rate_limit" || error.code === "over_email_send_rate_limit") {
      return { error: "Too many attempts. Wait a few minutes and try again.", email };
    }
    // Deliberately vague: never reveal whether an email is already registered.
    return {
      error: "We couldn't create that account. Check your details, or log in if you already have one.",
      email,
    };
  }

  // Confirm-email OFF (development): a session exists straight away.
  if (data.session) redirect("/onboarding");

  // Confirm-email ON: wait for the link.
  return { message: "Check your email for a confirmation link, then log in.", email };
}

export async function logIn(_prev: FormState, formData: FormData): Promise<FormState> {
  const parsed = credentials.safeParse({
    email: formData.get("email"),
    password: formData.get("password"),
  });
  if (!parsed.success) {
    return { error: parsed.error.issues[0].message, email: rawEmail(formData) };
  }
  const { email, password } = parsed.data;

  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword({ email, password });

  if (error) {
    if (error.code === "email_not_confirmed") {
      return { error: "Confirm your email first. Check your inbox for the link.", email };
    }
    if (error.code === "over_request_rate_limit") {
      return { error: "Too many attempts. Wait a few minutes and try again.", email };
    }
    return { error: "Incorrect email or password.", email };
  }

  // The (app) layout sends users without a profile on to /onboarding.
  redirect("/home");
}

export async function logOut() {
  const supabase = await createClient();
  // "local" ends this browser's session only. "Sign out everywhere" comes later.
  await supabase.auth.signOut({ scope: "local" });
  redirect("/login");
}
