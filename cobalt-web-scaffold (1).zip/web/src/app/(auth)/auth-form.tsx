"use client";

import Link from "next/link";
import { useActionState } from "react";
import type { FormState } from "@/lib/form-state";

type Props = {
  mode: "login" | "signup";
  action: (state: FormState, formData: FormData) => Promise<FormState>;
};

const input =
  "mt-1 block w-full rounded-lg border border-neutral-300 bg-white px-3 py-2 text-sm outline-none " +
  "focus:border-blue-600 focus:ring-2 focus:ring-blue-600/20 " +
  "dark:border-neutral-700 dark:bg-neutral-900";

export function AuthForm({ mode, action }: Props) {
  const [state, formAction, pending] = useActionState(action, undefined);
  const signup = mode === "signup";

  return (
    <form action={formAction} className="space-y-4" noValidate={false}>
      <div>
        <label htmlFor="email" className="text-sm font-medium">
          Email
        </label>
        <input
          id="email"
          name="email"
          type="email"
          autoComplete="email"
          required
          defaultValue={state?.email}
          className={input}
        />
      </div>

      <div>
        <label htmlFor="password" className="text-sm font-medium">
          Password
        </label>
        <input
          id="password"
          name="password"
          type="password"
          autoComplete={signup ? "new-password" : "current-password"}
          required
          minLength={8}
          maxLength={72}
          className={input}
        />
        {signup && (
          <p className="mt-1 text-xs text-neutral-500">At least 8 characters.</p>
        )}
      </div>

      {state?.error && (
        <p role="alert" className="text-sm text-red-600 dark:text-red-400">
          {state.error}
        </p>
      )}
      {state?.message && (
        <p role="status" className="text-sm text-emerald-700 dark:text-emerald-400">
          {state.message}
        </p>
      )}

      <button
        type="submit"
        disabled={pending}
        className="w-full rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-medium text-white hover:bg-blue-800 disabled:opacity-60"
      >
        {pending ? "Please wait…" : signup ? "Create account" : "Log in"}
      </button>

      <p className="text-center text-sm text-neutral-500">
        {signup ? (
          <>
            Already have an account?{" "}
            <Link href="/login" className="font-medium text-blue-700 dark:text-blue-400">
              Log in
            </Link>
          </>
        ) : (
          <>
            New to Cobalt?{" "}
            <Link href="/signup" className="font-medium text-blue-700 dark:text-blue-400">
              Create an account
            </Link>
          </>
        )}
      </p>
    </form>
  );
}
