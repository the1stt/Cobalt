import { AuthForm } from "../auth-form";
import { logIn } from "../actions";

const NOTICES: Record<string, string> = {
  confirm_failed: "That confirmation link is invalid or has expired. Log in, or sign up again.",
};

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const { error } = await searchParams;
  const notice = error ? NOTICES[error] : undefined;

  return (
    <>
      <h1 className="mb-4 text-lg font-medium">Log in</h1>
      {notice && (
        <p role="alert" className="mb-4 text-sm text-red-600 dark:text-red-400">
          {notice}
        </p>
      )}
      <AuthForm mode="login" action={logIn} />
    </>
  );
}
