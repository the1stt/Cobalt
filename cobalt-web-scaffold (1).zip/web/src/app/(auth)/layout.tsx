export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <main className="flex min-h-screen items-center justify-center bg-neutral-50 px-4 text-neutral-900 dark:bg-neutral-950 dark:text-neutral-100">
      <div className="w-full max-w-sm">
        <p className="text-2xl font-semibold tracking-tight">Cobalt</p>
        <p className="mb-8 text-sm text-neutral-500">
          A simulated bank. No real money moves here.
        </p>
        {children}
      </div>
    </main>
  );
}
