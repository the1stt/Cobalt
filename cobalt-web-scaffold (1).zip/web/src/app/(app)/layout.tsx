import { redirect } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { logOut } from "@/app/(auth)/actions";

// Every banking screen lives under (app). A user with no profile has not
// finished onboarding, so they are sent there. This is UX gating: the data
// itself is protected by row level security regardless of what the UI does.
export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser();
  const supabase = await createClient();
  const { data: profile } = await supabase
    .from("profiles")
    .select("handle")
    .eq("id", user.id)
    .maybeSingle();
  if (!profile) redirect("/onboarding");

  return (
    <div className="min-h-screen bg-neutral-50 text-neutral-900 dark:bg-neutral-950 dark:text-neutral-100">
      <header className="border-b border-neutral-200 dark:border-neutral-800">
        <div className="mx-auto flex max-w-2xl items-center justify-between px-4 py-3">
          <span className="font-semibold tracking-tight">Cobalt</span>
          <div className="flex items-center gap-4 text-sm">
            <span className="text-neutral-500">@{profile.handle}</span>
            <form action={logOut}>
              <button className="font-medium text-blue-700 dark:text-blue-400">Log out</button>
            </form>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-2xl px-4 py-8">{children}</main>
    </div>
  );
}
