import { createClient } from "@/lib/supabase/server";
import { formatUSD } from "@/lib/money";

export default async function HomePage() {
  const supabase = await createClient();

  // Row level security returns only the signed-in user's own account.
  const { data: account } = await supabase
    .from("accounts")
    .select("account_number, balance")
    .eq("type", "main")
    .maybeSingle();

  return (
    <section className="space-y-1">
      <p className="text-sm text-neutral-500">Balance</p>
      <p className="text-4xl font-semibold tabular-nums tracking-tight">
        {formatUSD(account?.balance ?? 0)}
      </p>
      {account && (
        <p className="text-sm text-neutral-500">
          Checking •••• {account.account_number?.slice(-4)}
        </p>
      )}
    </section>
  );
}
